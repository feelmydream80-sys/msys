from dotenv import load_dotenv
import os

load_dotenv()


DB_CONFIG = {
    "host": os.getenv("DB_HOST"),
    "dbname": os.getenv("DB_NAME"),
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "port": os.getenv("DB_PORT")  # 문자열로 읽혀도 psycopg2는 처리 가능
}

# print(os.getenv("DB_NAME"))
# 계속 db_name이 .env 파일을 변경했는데도 변경되지 않아 체크함. vscode 재 실행하니 정상동작함