# 필드명 네이밍 규칙 (Field Naming Convention)

> **원칙: 모든 계층은 DB 테이블 컬럼명과 일치하는 필드명을 사용한다**

## 개요

msys 프로젝트에서 Frontend, Backend, Database 간 데이터 교환 시 **필드명 일관성**을 유지하기 위한 규칙입니다.

## 핵심 원칙

```
Frontend (JS)  ←→  Backend (Python)  ←→  Database (PostgreSQL)
     titl     ←→       titl         ←→      TITL
     cont     ←→       cont         ←→      CONT
   start_dt   ←→     start_dt       ←→    START_DT
```

**모든 계층에서 동일한 명명법 사용** - 변환/매핑 로직 최소화

## 명명 규칙

### 1. DB 컬럼명 기준

- **기준**: `information_schema.columns` 또는 DDL 정의의 컬럼명
- **형식**: 대문자 + 언더스코어 (예: `START_DT`, `HIDE_OPT_YN`)
- **변환**: Frontend/Backend에서는 소문자로 사용 (예: `start_dt`, `hide_opt_yn`)

### 2. 계층별 적용

| 계층 | 명명 규칙 | 예시 |
|------|----------|------|
| **Database** | 대문자 스네이크 | `TITL`, `CONT`, `START_DT` |
| **Backend (Python)** | 소문자 스네이크 | `titl`, `cont`, `start_dt` |
| **Frontend (JS)** | 소문자 스네이크 | `titl`, `cont`, `start_dt` |
| **FormData** | 소문자 스네이크 | `titl`, `cont`, `start_dt` |
| **JSON** | 소문자 스네이크 | `titl`, `cont`, `start_dt` |

### 3. 사용 금지

❌ **절대 사용하지 말 것**:
- 풀네임 (예: `title`, `content`, `start_time`) 
- 칵케이스 (예: `startDt`, `hideOptYn`)
- 축약형 변형 (예: `ttl`, `cnt`, `sdt`)

✅ **항상 사용할 것**:
- DB 컬럼명과 정확히 일치하는 소문자 스네이크

## 적용 예시 (TB_POPUP_MST)

| DB 컬럼명 | Backend | Frontend | FormData 필드 |
|-----------|---------|----------|---------------|
| `POPUP_ID` | `popup_id` | `popup_id` | - (auto) |
| `TITL` | `titl` | `titl` | `titl` |
| `CONT` | `cont` | `cont` | `cont` |
| `IMG_PATH` | `img_path` | `img_path` | `img_path` |
| `LNK_URL` | `lnk_url` | `lnk_url` | `lnk_url` |
| `START_DT` | `start_dt` | `start_dt` | `start_dt` |
| `END_DT` | `end_dt` | `end_dt` | `end_dt` |
| `USE_YN` | `use_yn` | `use_yn` | `use_yn` |
| `DISP_ORD` | `disp_ord` | `disp_ord` | `disp_ord` |
| `DISP_TYPE` | `disp_type` | `disp_type` | `disp_type` |
| `WIDTH` | `width` | `width` | `width` |
| `HEIGHT` | `height` | `height` | `height` |
| `BG_COLR` | `bg_colr` | `bg_colr` | `bg_colr` |
| `HIDE_OPT_YN` | `hide_opt_yn` | `hide_opt_yn` | `hide_opt_yn` |
| `HIDE_DAYS_MAX` | `hide_days_max` | `hide_days_max` | `hide_days_max` |
| `REG_USER_ID` | `reg_user_id` | - | - |
| `REG_DT` | `reg_dt` | - | - |
| `UPD_USER_ID` | `upd_user_id` | - | - |
| `UPD_DT` | `upd_dt` | - | - |

## FormData 처리 규칙

```python
# Backend (Flask) - 올바른 예
@app.route('/api/popups', methods=['POST'])
def create_popup():
    data = {
        'TITL': request.form.get('titl'),        # ✓ DB 컬럼명 (대문자)
        'CONT': request.form.get('cont'),        # ✓ DB 컬럼명 (대문자)
        'START_DT': request.form.get('start_dt'), # ✓ DB 컬럼명 (대문자)
        # ...
    }
```

```javascript
// Frontend (JS) - 올바른 예
const formData = new FormData();
formData.append('titl', document.getElementById('popupTitle').value);        // ✓ 소문자
formData.append('cont', document.getElementById('popupContent').value);      // ✓ 소문자
formData.append('start_dt', startDate + ' 00:00:00');                        // ✓ 소문자
```

## 위반 시 조치

필드명 불일치로 인한 400/500 오류 발생 시:
1. **원인**: 계층 간 필드명 불일치
2. **해결**: DB 컬럼명 기준으로 모든 계층 통일
3. **예방**: 개발 전 해당 테이블 DDL 확인 필수

## 관련 문서

- [Database Naming Standard](../development/database-naming-standard.md)
- [Data Handling Rules](./data-handling-rules.md)

---

**생성일**: 2026-04-15  
**목적**: REQ-2604-005 팝업 기능 개발 중 필드명 불일치 문제 해결 및 예방
