# 🔴 msys 데이터 처리 규칙

> ⚠️ **위반 시 경고 후 사용자 확인 필수**

## 1. 시간/날짜 처리

### DB 저장
- KST (UTC+9) 기준
- `TIMESTAMP WITHOUT TIME ZONE`

### DAO SQL 조회 (필수)
```sql
-- ✅ 올바름
SELECT TO_CHAR(created_at, 'YYYY-MM-DD HH24:MI:SS') as created_at
FROM TB_TABLE;

-- ❌ 금지
SELECT created_at FROM TB_TABLE;
```

### Python
- 생성: `utils.datetime_utils.get_kst_now()`
- 금지: `datetime.now()`, `datetime.utcnow()`

### JavaScript (static/js/modules/common/dateUtils.js)
- 생성: `getKSTNow()`
- 표시: `formatDBDateTime()`
- 금지: `new Date()`, `Date.now()`

## 2. 위반 시 처리

AI가 다음 사항 발견 시:
1. 작업 중단
2. 위반 내용과 해결책 제시
3. 사용자 확인 후 진행

### 절대 금지
- datetime 객체를 jsonify로 반환
- TO_CHAR 없이 datetime 조회
- new Date()로 시간 생성
- dateUtils 우회하는 코드
